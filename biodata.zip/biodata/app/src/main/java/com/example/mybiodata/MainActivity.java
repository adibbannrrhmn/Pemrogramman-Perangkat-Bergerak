package com.example.mybiodata;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class
MainActivity extends AppCompatActivity {

    private static final int REQUEST_PHONE_CALL = 1;
    TextView txtDesc;

    //ListView listView;
    private Object TextView;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtDesc = findViewById(R.id.txtDesc);
        txtDesc.setMovementMethod(new ScrollingMovementMethod());

    }

    public void alamat(View v) {
        Uri map = Uri.parse("https://www.google.co.id/maps/dir//Tempaling,+Kec.+Pamotan,+Kabupaten+Rembang,+Jawa+Tengah+59261/@-6.774678,111.4508618,18.3z/data=!4m8!4m7!1m0!1m5!1m1!1s0x2e773d37bc6c9015:0x7f79eac221cc6fba!2m2!1d111.4496852!2d-6.7751341");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, map);

        startActivity(mapIntent);
    }


    public void kontak(View view) {
        String number = "6285865474372";
        String url = "https://api.whatsapp.com/send?phone=" + number;
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setPackage("com.whatsapp");
        i.setData(Uri.parse(url));
        startActivity(i);
    }

    public void email(View v){
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] {"111202113712@mhs.dinus.ac.id"});
        intent.putExtra(Intent.EXTRA_CC, new String[] {"adibannur300@gmail.com"});
        intent.putExtra(Intent.EXTRA_SUBJECT, "Email dari Aplikasi Android");
        intent.putExtra(Intent.EXTRA_TEXT, "Hai, ini adalah percobaan mengirim email dari aplikasi android");

        try {
            startActivity(Intent.createChooser(intent, "Ingin Mengirim Email ?"));
        } catch (android.content.ActivityNotFoundException ex) {
            //do something else
        }
    }
}