package com.example.anekakuliner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telecom.Call;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String nama_makanan[]={"Rendang Padang","Ayam Geprek Original","Chicken Katsu","Ayam Geprek Keju","Soto Lamongan","Sate Ayam Madura","Sate Kambing","Mie Ayam Pangsit"};

        String harga_makanan[]={"Rp.10.000","Rp.10.000","Rp.13.000","Rp.15.000","Rp.10.000","Rp.15.000","Rp.20.000","Rp.10.000"};

        int gambar_makanan[]={R.drawable.lapis, R.drawable.ayampenyet, R.drawable.ayamkatsu, R.drawable.ayamgeprekkeju, R.drawable.sotolamongan, R.drawable.sateayam,
                            R.drawable.satesapi, R.drawable.mieayam};

        String keterangan[]={"Rendang khas padang yang memiliki citarasa yang khas dari masakan Padang dan daging yang lembut",
                "Ayam Geprek Original ini memiliki citarasa khas nusantara dari sambalnya yang bisa direquest sesuai keinginan",
                "Ayam katsu makanan yang identik dengan negara jepang dengan kenikmatan tersendiri bagi penikmatnya",
                "Ayam geprek keju ini berdeda dari yang original, karena di kasih topping keju di atasnya yang membuat penikmatnya tidak sabar untuk menkmatinya",
                "Soto Lamongan makanan asli Kota Lamongan Jawa Timur yang memiliki cita rasa yang segar ketika dimakan",
                "Sate Ayam Madura ini selalu nikmat ketika di santap dengan nasi apalagi taburi bumbu kacangnya yang khas",
                "Sate Kambing selalu nikmat ketika di santap dengan nasi dan cocok untuk orang darah rendah",
                "Mie Ayam dengan topping ayam dan pangsit yang melimpah cocok dinikmati saat musim hujan seperti sekarang ini"};

        String harga[]={"Rp.15.000","Rp.10.000", "Rp.13.000","Rp17.000","Rp.10.000","Rp.15.000","Rp.30.000","Rp.8.000"};


    listView=findViewById(R.id.listkuliner);
    AdapterKuliner adapterKuliner=new AdapterKuliner(this, nama_makanan, gambar_makanan, keterangan, harga_makanan, harga);
    listView.setAdapter(adapterKuliner);
    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
            String nm_makanan=nama_makanan[position].toString();
            String hrg_makanan=harga_makanan[position].toString();
            int gbr_makanan=gambar_makanan[position];
            String ket=keterangan[position].toString();
            String hrg=harga[position].toString();

            Intent intent=new Intent(MainActivity.this, DetilKuliner.class);
            intent.putExtra("namamakanan", nm_makanan);
            intent.putExtra("gambarmakanan", gbr_makanan);
            intent.putExtra("keter", ket);
            intent.putExtra("hargamakanan", hrg_makanan);
            intent.putExtra("ketera", hrg);
            startActivity(intent);
        }
    });

    }
}